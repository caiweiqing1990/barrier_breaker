#ifndef __CJB_TIMER_H__
#define __CJB_TIMER_H__

#include <stdio.h>

extern seconds_sleep(unsigned seconds);
extern milliseconds_sleep(unsigned long milliseconds);
extern microseconds_sleep(unsigned long microseconds);

#endif
